module.exports = {
    database: 'postgres',
    host: 'quire-dev.cdjz0rybmy8p.us-east-1.rds.amazonaws.com',
    port: '5432',
    user: 'root',
    password: 'rootpassword'
}