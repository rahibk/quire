# Endpoints  
## Users  
### Get all users  
`GET /users`

### Get specific users
`GET /users/{user_id}` 

### Insert user
`POST /users/new`
| Parameters    |
| ------------- |
| firstName     | 
| lastName      | 
| emailAddress  | 