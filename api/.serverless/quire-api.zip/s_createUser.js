
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kpetkar21',
  applicationName: 'quire-api-app',
  appUid: 'SzNkHz4jxpXTGfXcth',
  orgUid: '3Mwt2sZMv6q3Vf2MlJ',
  deploymentUid: '085a0b6a-01ae-492f-8bd9-e2d2ca85a0b8',
  serviceName: 'quire-api',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'quire-api-dev-createUser', timeout: 6 };

try {
  const userHandler = require('./handlers/users.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createUser, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}